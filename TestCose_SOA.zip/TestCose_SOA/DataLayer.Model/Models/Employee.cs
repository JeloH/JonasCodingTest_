﻿using System;
using System.Collections.Generic;

namespace DataAccessLayer.Model.Models
{
    public class Employee : DataEntity
    {
        public string SiteId { get; set; }
        public string CompanyCode { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string Occuption { get; set; }
        public string EmployeeStatus { get; set; }
        public string EmailAddress { get; set; }
        public string Phone { get; set; }
        public DateTime LastModified { get; set; }
    }
}
