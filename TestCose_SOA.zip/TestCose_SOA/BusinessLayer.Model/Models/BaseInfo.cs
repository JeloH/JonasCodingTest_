﻿namespace BusinessLayer.Model.Models
{
    public class BaseInfo
    {
        public string SiteId { get; set; }
        public string CompanyCode { get; set; }
    }
}